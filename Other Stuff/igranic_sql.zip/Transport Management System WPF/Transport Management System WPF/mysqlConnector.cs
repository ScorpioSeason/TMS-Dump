﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//from https://www.codeproject.com/articles/43438/connect-c-to-mysql


namespace Transport_Management_System_WPF
{
    class mysqlConnector
    {

    }
}

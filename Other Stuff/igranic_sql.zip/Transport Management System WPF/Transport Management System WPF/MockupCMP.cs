﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Transport_Management_System_WPF
{
    // This is a temporary stub for the incoming CMP data. 
    class MockupCMP
    {
        string[] MockEntries = {"|Hardware Depot|0|0|Belleville|Windsor|0|",
                                  "Atlantis Railway|1|3|Hamilton|Oshawa|0|",
                                  "Big Oil|0|0|Windsor|Hamilton|1|",
                                  "Rockomax Engineering|1|10|Belleville|Toronto|1|",
                                  "Space J|0|0|Toronto|Belleville|1|",
                                  "Rockomax Engineering|0|0|Belleville|Ottawa|1|",
                                  "Tom Hortons|0|0|Ottawa|Toronto|0|",
                                  "Sushi Noodle|0|0|Toronto|Ottawa|0",
                                  "Atlantis|Railway|0|0|Kingston|Windsor|0|"
                                  };
    }
}

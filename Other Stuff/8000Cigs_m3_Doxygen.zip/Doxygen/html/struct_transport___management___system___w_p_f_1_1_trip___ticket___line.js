var struct_transport___management___system___w_p_f_1_1_trip___ticket___line =
[
    [ "Date_Added", "struct_transport___management___system___w_p_f_1_1_trip___ticket___line.html#a1c46324af80772864f103e4564f40c14", null ],
    [ "Route", "struct_transport___management___system___w_p_f_1_1_trip___ticket___line.html#a4681ae5f7c24c679200f3d3e435b9270", null ],
    [ "Ticket", "struct_transport___management___system___w_p_f_1_1_trip___ticket___line.html#ad6c1218c6657864ef7584c30133d423f", null ]
];
var hierarchy =
[
    [ "TMSwPages.Admin", "class_t_m_sw_pages_1_1_admin.html", null ],
    [ "TMSwPages.AlterTables", "class_t_m_sw_pages_1_1_alter_tables.html", null ],
    [ "Application", null, [
      [ "TMSwPages::App", "class_t_m_sw_pages_1_1_app.html", null ],
      [ "Transport_Management_System_WPF::App", "class_transport___management___system___w_p_f_1_1_app.html", null ]
    ] ],
    [ "TMSwPages.BackupTMS", "class_t_m_sw_pages_1_1_backup_t_m_s.html", null ],
    [ "Transport_Management_System_WPF.BuyerClass", "class_transport___management___system___w_p_f_1_1_buyer_class.html", null ],
    [ "Transport_Management_System_WPF.Carrier", "class_transport___management___system___w_p_f_1_1_carrier.html", null ],
    [ "Transport_Management_System_WPF.CityNode", "class_transport___management___system___w_p_f_1_1_city_node.html", null ],
    [ "Transport_Management_System_WPF.Contract", "class_transport___management___system___w_p_f_1_1_contract.html", null ],
    [ "Transport_Management_System_WPF.Customer", "struct_transport___management___system___w_p_f_1_1_customer.html", null ],
    [ "Transport_Management_System_WPF.Location", "struct_transport___management___system___w_p_f_1_1_location.html", null ],
    [ "Transport_Management_System_WPF.MappingClass", "class_transport___management___system___w_p_f_1_1_mapping_class.html", null ],
    [ "Transport_Management_System_WPF.mysqlConnector", "class_transport___management___system___w_p_f_1_1mysql_connector.html", null ],
    [ "NavigationWindow", null, [
      [ "TMSwPages::MainWindow", "class_t_m_sw_pages_1_1_main_window.html", null ]
    ] ],
    [ "Page", null, [
      [ "TMSwPages::AdminPage", "class_t_m_sw_pages_1_1_admin_page.html", null ],
      [ "TMSwPages::ViewLogDetails", "class_t_m_sw_pages_1_1_view_log_details.html", null ]
    ] ],
    [ "Transport_Management_System_WPF.PlannerClass.Planner", "class_transport___management___system___w_p_f_1_1_planner_class_1_1_planner.html", null ],
    [ "Transport_Management_System_WPF.PlannerClass", "class_transport___management___system___w_p_f_1_1_planner_class.html", null ],
    [ "UnitTestTMS.PlannerClassTests", "class_unit_test_t_m_s_1_1_planner_class_tests.html", null ],
    [ "Transport_Management_System_WPF.RouteData", "struct_transport___management___system___w_p_f_1_1_route_data.html", null ],
    [ "Transport_Management_System_WPF.RouteSumData", "struct_transport___management___system___w_p_f_1_1_route_sum_data.html", null ],
    [ "Transport_Management_System_WPF.SQL_Query", "class_transport___management___system___w_p_f_1_1_s_q_l___query.html", null ],
    [ "Transport_Management_System_WPF.SQL_Query_TMS", "class_transport___management___system___w_p_f_1_1_s_q_l___query___t_m_s.html", null ],
    [ "UnitTestTMS.PlannerClassTests.TestingContract", "struct_unit_test_t_m_s_1_1_planner_class_tests_1_1_testing_contract.html", null ],
    [ "Transport_Management_System_WPF.TimePass", "class_transport___management___system___w_p_f_1_1_time_pass.html", null ],
    [ "TMSwPages.TMSLog", "class_t_m_sw_pages_1_1_t_m_s_log.html", null ],
    [ "TMSwPages.TMSLogger", "class_t_m_sw_pages_1_1_t_m_s_logger.html", null ],
    [ "Transport_Management_System_WPF.Trip_Ticket", "struct_transport___management___system___w_p_f_1_1_trip___ticket.html", null ],
    [ "Transport_Management_System_WPF.Trip_Ticket_Line", "struct_transport___management___system___w_p_f_1_1_trip___ticket___line.html", null ],
    [ "Transport_Management_System_WPF.Truck", "struct_transport___management___system___w_p_f_1_1_truck.html", null ],
    [ "UnitTestTMS.UnitTest2", "class_unit_test_t_m_s_1_1_unit_test2.html", null ],
    [ "Window", null, [
      [ "Transport_Management_System_WPF::MainWindow", "class_transport___management___system___w_p_f_1_1_main_window.html", null ]
    ] ]
];
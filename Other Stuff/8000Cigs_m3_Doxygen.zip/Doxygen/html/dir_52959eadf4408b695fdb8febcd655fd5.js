var dir_52959eadf4408b695fdb8febcd655fd5 =
[
    [ "AdminClasses.cs", "_transport_01_management_01_system_01_w_p_f_2_admin_classes_8cs.html", [
      [ "Admin", "class_t_m_sw_pages_1_1_admin.html", "class_t_m_sw_pages_1_1_admin" ],
      [ "TMSLogger", "class_t_m_sw_pages_1_1_t_m_s_logger.html", "class_t_m_sw_pages_1_1_t_m_s_logger" ],
      [ "TMSLog", "class_t_m_sw_pages_1_1_t_m_s_log.html", "class_t_m_sw_pages_1_1_t_m_s_log" ],
      [ "BackupTMS", "class_t_m_sw_pages_1_1_backup_t_m_s.html", null ],
      [ "AlterTables", "class_t_m_sw_pages_1_1_alter_tables.html", null ]
    ] ],
    [ "App.xaml.cs", "_transport_01_management_01_system_01_w_p_f_2_app_8xaml_8cs.html", [
      [ "App", "class_transport___management___system___w_p_f_1_1_app.html", null ]
    ] ],
    [ "BuyerClass.cs", "_buyer_class_8cs.html", [
      [ "BuyerClass", "class_transport___management___system___w_p_f_1_1_buyer_class.html", "class_transport___management___system___w_p_f_1_1_buyer_class" ]
    ] ],
    [ "Carrier.cs", "_carrier_8cs.html", [
      [ "Carrier", "class_transport___management___system___w_p_f_1_1_carrier.html", "class_transport___management___system___w_p_f_1_1_carrier" ]
    ] ],
    [ "Contract.cs", "_contract_8cs.html", [
      [ "Contract", "class_transport___management___system___w_p_f_1_1_contract.html", "class_transport___management___system___w_p_f_1_1_contract" ]
    ] ],
    [ "MainWindow.xaml.cs", "_transport_01_management_01_system_01_w_p_f_2mainwindow_8xaml_8cs.html", [
      [ "MainWindow", "class_transport___management___system___w_p_f_1_1_main_window.html", "class_transport___management___system___w_p_f_1_1_main_window" ]
    ] ],
    [ "MappingClass.cs", "_mapping_class_8cs.html", [
      [ "RouteData", "struct_transport___management___system___w_p_f_1_1_route_data.html", "struct_transport___management___system___w_p_f_1_1_route_data" ],
      [ "RouteSumData", "struct_transport___management___system___w_p_f_1_1_route_sum_data.html", "struct_transport___management___system___w_p_f_1_1_route_sum_data" ],
      [ "CityNode", "class_transport___management___system___w_p_f_1_1_city_node.html", "class_transport___management___system___w_p_f_1_1_city_node" ],
      [ "MappingClass", "class_transport___management___system___w_p_f_1_1_mapping_class.html", "class_transport___management___system___w_p_f_1_1_mapping_class" ]
    ] ],
    [ "mysqlConnector.cs", "mysql_connector_8cs.html", [
      [ "mysqlConnector", "class_transport___management___system___w_p_f_1_1mysql_connector.html", null ]
    ] ],
    [ "PlannerClass.cs", "_planner_class_8cs.html", [
      [ "Customer", "struct_transport___management___system___w_p_f_1_1_customer.html", "struct_transport___management___system___w_p_f_1_1_customer" ],
      [ "Trip_Ticket", "struct_transport___management___system___w_p_f_1_1_trip___ticket.html", "struct_transport___management___system___w_p_f_1_1_trip___ticket" ],
      [ "Trip_Ticket_Line", "struct_transport___management___system___w_p_f_1_1_trip___ticket___line.html", "struct_transport___management___system___w_p_f_1_1_trip___ticket___line" ],
      [ "Location", "struct_transport___management___system___w_p_f_1_1_location.html", "struct_transport___management___system___w_p_f_1_1_location" ],
      [ "Truck", "struct_transport___management___system___w_p_f_1_1_truck.html", "struct_transport___management___system___w_p_f_1_1_truck" ],
      [ "PlannerClass", "class_transport___management___system___w_p_f_1_1_planner_class.html", [
        [ "Planner", "class_transport___management___system___w_p_f_1_1_planner_class_1_1_planner.html", "class_transport___management___system___w_p_f_1_1_planner_class_1_1_planner" ]
      ] ],
      [ "Planner", "class_transport___management___system___w_p_f_1_1_planner_class_1_1_planner.html", "class_transport___management___system___w_p_f_1_1_planner_class_1_1_planner" ]
    ] ],
    [ "SQL_Query.cs", "_s_q_l___query_8cs.html", [
      [ "SQL_Query", "class_transport___management___system___w_p_f_1_1_s_q_l___query.html", "class_transport___management___system___w_p_f_1_1_s_q_l___query" ]
    ] ],
    [ "SQL_Query_TMS.cs", "_s_q_l___query___t_m_s_8cs.html", [
      [ "SQL_Query_TMS", "class_transport___management___system___w_p_f_1_1_s_q_l___query___t_m_s.html", "class_transport___management___system___w_p_f_1_1_s_q_l___query___t_m_s" ]
    ] ],
    [ "TimePass.cs", "_time_pass_8cs.html", [
      [ "TimePass", "class_transport___management___system___w_p_f_1_1_time_pass.html", "class_transport___management___system___w_p_f_1_1_time_pass" ]
    ] ]
];
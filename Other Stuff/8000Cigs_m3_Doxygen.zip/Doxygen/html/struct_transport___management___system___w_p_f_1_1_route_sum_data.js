var struct_transport___management___system___w_p_f_1_1_route_sum_data =
[
    [ "DestinationCity", "struct_transport___management___system___w_p_f_1_1_route_sum_data.html#aa785d7de7cf9f051b5d6e00c6e1aaa08", null ],
    [ "OriginCity", "struct_transport___management___system___w_p_f_1_1_route_sum_data.html#a3d2ddcb564dfc2322a2b50156df0f72e", null ],
    [ "totalDriveTime", "struct_transport___management___system___w_p_f_1_1_route_sum_data.html#a4519225a57727b844e4adcdc5e4ec378", null ],
    [ "totalKM", "struct_transport___management___system___w_p_f_1_1_route_sum_data.html#aaca3e4b028ef7381d995d32103f44704", null ],
    [ "totalTripTime", "struct_transport___management___system___w_p_f_1_1_route_sum_data.html#a3912f1c48f71e670dcaa4f8455100a56", null ]
];
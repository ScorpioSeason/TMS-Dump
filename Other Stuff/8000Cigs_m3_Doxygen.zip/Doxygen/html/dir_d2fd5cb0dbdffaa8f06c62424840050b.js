var dir_d2fd5cb0dbdffaa8f06c62424840050b =
[
    [ "AdminClasses.cs", "_t_m_sw_pages_2_admin_classes_8cs.html", [
      [ "Admin", "class_t_m_sw_pages_1_1_admin.html", "class_t_m_sw_pages_1_1_admin" ],
      [ "TMSLogger", "class_t_m_sw_pages_1_1_t_m_s_logger.html", "class_t_m_sw_pages_1_1_t_m_s_logger" ],
      [ "TMSLog", "class_t_m_sw_pages_1_1_t_m_s_log.html", "class_t_m_sw_pages_1_1_t_m_s_log" ],
      [ "BackupTMS", "class_t_m_sw_pages_1_1_backup_t_m_s.html", null ],
      [ "AlterTables", "class_t_m_sw_pages_1_1_alter_tables.html", null ]
    ] ],
    [ "AdminPage.xaml.cs", "_admin_page_8xaml_8cs.html", [
      [ "AdminPage", "class_t_m_sw_pages_1_1_admin_page.html", "class_t_m_sw_pages_1_1_admin_page" ]
    ] ],
    [ "App.xaml.cs", "_t_m_sw_pages_2_app_8xaml_8cs.html", [
      [ "App", "class_t_m_sw_pages_1_1_app.html", null ]
    ] ],
    [ "mainwindow.xaml.cs", "_t_m_sw_pages_2mainwindow_8xaml_8cs.html", [
      [ "MainWindow", "class_t_m_sw_pages_1_1_main_window.html", "class_t_m_sw_pages_1_1_main_window" ]
    ] ],
    [ "ViewLogDetails.xaml.cs", "_view_log_details_8xaml_8cs.html", [
      [ "ViewLogDetails", "class_t_m_sw_pages_1_1_view_log_details.html", "class_t_m_sw_pages_1_1_view_log_details" ]
    ] ]
];
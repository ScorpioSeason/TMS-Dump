var struct_transport___management___system___w_p_f_1_1_truck =
[
    [ "CurrentCityID", "struct_transport___management___system___w_p_f_1_1_truck.html#a71ec212b9661e6c7e40d1f2595f0ce64", null ],
    [ "Free_Space", "struct_transport___management___system___w_p_f_1_1_truck.html#a9bb588a62475d3fffe50338f4ad756d5", null ],
    [ "FTL_or_LTL", "struct_transport___management___system___w_p_f_1_1_truck.html#a15e0339edac3a7aae1a720bd4d1ae8ca", null ],
    [ "Is_Reefer", "struct_transport___management___system___w_p_f_1_1_truck.html#a19d9ffdc88f86af4a2dcd36d8a490daf", null ],
    [ "TruckID", "struct_transport___management___system___w_p_f_1_1_truck.html#a32fbe494f246831d2559c25f348c6b18", null ],
    [ "Waiting_or_Transit", "struct_transport___management___system___w_p_f_1_1_truck.html#a81ccff97235613b950395988d4e26d52", null ]
];
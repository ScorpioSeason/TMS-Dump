var struct_transport___management___system___w_p_f_1_1_trip___ticket =
[
    [ "Days_Passed", "struct_transport___management___system___w_p_f_1_1_trip___ticket.html#aa6fe515cc7c37d8caf41dcaf4ae7a80a", null ],
    [ "FTL_or_LTL", "struct_transport___management___system___w_p_f_1_1_trip___ticket.html#aedde328df4cc5ee04967a294549e3d53", null ],
    [ "Is_Complete", "struct_transport___management___system___w_p_f_1_1_trip___ticket.html#a478f4ac1e28bf46a22e1765d96dada0b", null ],
    [ "Is_Reefer", "struct_transport___management___system___w_p_f_1_1_trip___ticket.html#a027a527cbc51146bd409a8b2f188156d", null ],
    [ "Size_In_Palette", "struct_transport___management___system___w_p_f_1_1_trip___ticket.html#afbb9ff414d4e62f54c5bc1b3ed449cd2", null ],
    [ "TicketID", "struct_transport___management___system___w_p_f_1_1_trip___ticket.html#acf7c3fb5a7f04d0857f0c4b34cff05b0", null ],
    [ "TruckID", "struct_transport___management___system___w_p_f_1_1_trip___ticket.html#a4d7ee0e3563b272b18bc947264f2aac0", null ]
];
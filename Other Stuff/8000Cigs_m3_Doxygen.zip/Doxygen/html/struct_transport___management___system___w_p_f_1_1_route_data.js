var struct_transport___management___system___w_p_f_1_1_route_data =
[
    [ "CityA", "struct_transport___management___system___w_p_f_1_1_route_data.html#a78ab42300dd9923b0d9914c6fa57441c", null ],
    [ "CityB", "struct_transport___management___system___w_p_f_1_1_route_data.html#a4b5ac67440353f1061ba8ba3cbcabc92", null ],
    [ "DriveTime", "struct_transport___management___system___w_p_f_1_1_route_data.html#a1c014862156bfa9f7f5c3177e8a8dc30", null ],
    [ "DropoffTime", "struct_transport___management___system___w_p_f_1_1_route_data.html#a822646cabf49a7459b97f0aad3bfb838", null ],
    [ "KM", "struct_transport___management___system___w_p_f_1_1_route_data.html#a23cd8f5e8ad99be71ea319ae12706e35", null ],
    [ "LtlTime", "struct_transport___management___system___w_p_f_1_1_route_data.html#aac1cdb60d3446d2a2ee8965f11356b72", null ],
    [ "PickupTime", "struct_transport___management___system___w_p_f_1_1_route_data.html#a8a1fb3b1c950746f7f44960742163436", null ],
    [ "RouteDataID", "struct_transport___management___system___w_p_f_1_1_route_data.html#a7c32b69555f2b7546a00cbb7cc1fc4b2", null ]
];
var namespaces_dup =
[
    [ "TMSwPages", "namespace_t_m_sw_pages.html", null ],
    [ "Transport_Management_System_WPF", "namespace_transport___management___system___w_p_f.html", null ],
    [ "UnitTestTMS", "namespace_unit_test_t_m_s.html", null ]
];
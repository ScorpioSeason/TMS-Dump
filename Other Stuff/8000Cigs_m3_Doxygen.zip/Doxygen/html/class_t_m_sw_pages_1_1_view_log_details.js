var class_t_m_sw_pages_1_1_view_log_details =
[
    [ "ViewLogDetails", "class_t_m_sw_pages_1_1_view_log_details.html#a52d7460a3afa1e236afeeeb29c88584c", null ],
    [ "ViewLogDetails", "class_t_m_sw_pages_1_1_view_log_details.html#a39a52a42ed73d7cff66d36a22639806c", null ]
];
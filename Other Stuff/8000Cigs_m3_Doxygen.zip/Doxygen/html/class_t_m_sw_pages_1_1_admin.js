var class_t_m_sw_pages_1_1_admin =
[
    [ "Admin", "class_t_m_sw_pages_1_1_admin.html#a9544cc6cc847d75e5eca01c31dfa7655", null ],
    [ "Admin", "class_t_m_sw_pages_1_1_admin.html#a9544cc6cc847d75e5eca01c31dfa7655", null ],
    [ "adminAlter", "class_t_m_sw_pages_1_1_admin.html#a1fa24937bf3f23bdb385ed055873ad35", null ],
    [ "adminBackup", "class_t_m_sw_pages_1_1_admin.html#a8a5920a3a10044bd01c6597febf53489", null ]
];
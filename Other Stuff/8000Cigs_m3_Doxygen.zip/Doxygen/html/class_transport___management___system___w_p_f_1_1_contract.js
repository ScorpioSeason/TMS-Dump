var class_transport___management___system___w_p_f_1_1_contract =
[
    [ "ToCityID", "class_transport___management___system___w_p_f_1_1_contract.html#a254ed52cf71342faa887347d1b3ca016", null ],
    [ "nominatedCarriers", "class_transport___management___system___w_p_f_1_1_contract.html#ae7c3e9a488287e6703064acda1bed8d1", null ],
    [ "client_Name", "class_transport___management___system___w_p_f_1_1_contract.html#a41ac173e3c56e0ae7f6a114635c3384f", null ],
    [ "destination", "class_transport___management___system___w_p_f_1_1_contract.html#a3609748147e09807df18d132b3e899d9", null ],
    [ "job_Type", "class_transport___management___system___w_p_f_1_1_contract.html#aca3e55529a8daa8e8374f2e09fd943a6", null ],
    [ "origin", "class_transport___management___system___w_p_f_1_1_contract.html#a94cc2bb53b867ee05003849bb3d954d6", null ],
    [ "quantity", "class_transport___management___system___w_p_f_1_1_contract.html#a0e5bada08c53049adfc4a73271316692", null ],
    [ "van_Type", "class_transport___management___system___w_p_f_1_1_contract.html#a5fbe75b711bca7ae679a905b87b39d21", null ]
];
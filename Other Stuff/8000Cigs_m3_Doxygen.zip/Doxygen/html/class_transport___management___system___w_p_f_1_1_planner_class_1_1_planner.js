var class_transport___management___system___w_p_f_1_1_planner_class_1_1_planner =
[
    [ "Receive_Customer_Order_From_Buyer", "class_transport___management___system___w_p_f_1_1_planner_class_1_1_planner.html#aed4be49ed7fadb9ff44f0e0fe4e20b26", null ]
];
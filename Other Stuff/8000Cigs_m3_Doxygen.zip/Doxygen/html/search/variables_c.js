var searchData=
[
  ['searchresults_283',['searchResults',['../class_t_m_sw_pages_1_1_admin_page.html#a0086ede2b1f65bf900f3d7a735be4ae6',1,'TMSwPages::AdminPage']]],
  ['server_284',['server',['../class_transport___management___system___w_p_f_1_1_s_q_l___query.html#a74e809c491defe9a639c92f31fd21cbb',1,'Transport_Management_System_WPF.SQL_Query.server()'],['../class_transport___management___system___w_p_f_1_1_s_q_l___query___t_m_s.html#a1925e46bbbaca908c0c5c791a6d3db4f',1,'Transport_Management_System_WPF.SQL_Query_TMS.server()']]],
  ['size_5fin_5fpalette_285',['Size_In_Palette',['../struct_transport___management___system___w_p_f_1_1_trip___ticket.html#afbb9ff414d4e62f54c5bc1b3ed449cd2',1,'Transport_Management_System_WPF::Trip_Ticket']]]
];

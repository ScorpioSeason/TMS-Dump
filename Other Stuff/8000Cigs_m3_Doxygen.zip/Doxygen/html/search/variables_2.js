var searchData=
[
  ['citya_255',['CityA',['../struct_transport___management___system___w_p_f_1_1_route_data.html#a78ab42300dd9923b0d9914c6fa57441c',1,'Transport_Management_System_WPF::RouteData']]],
  ['cityb_256',['CityB',['../struct_transport___management___system___w_p_f_1_1_route_data.html#a4b5ac67440353f1061ba8ba3cbcabc92',1,'Transport_Management_System_WPF::RouteData']]],
  ['cityname_257',['CityName',['../struct_transport___management___system___w_p_f_1_1_location.html#a848c8cf678e3b58452154a08f850c3e1',1,'Transport_Management_System_WPF::Location']]],
  ['connection_258',['connection',['../class_transport___management___system___w_p_f_1_1_s_q_l___query.html#af7b60498e05b190cb6a67624ef511bdb',1,'Transport_Management_System_WPF.SQL_Query.connection()'],['../class_transport___management___system___w_p_f_1_1_s_q_l___query___t_m_s.html#ae892a829faf4f780b88920b944098a20',1,'Transport_Management_System_WPF.SQL_Query_TMS.connection()']]],
  ['contracts_259',['contracts',['../class_transport___management___system___w_p_f_1_1_buyer_class.html#a57b54a05ef81b5b5b578d5bfc6485a10',1,'Transport_Management_System_WPF::BuyerClass']]],
  ['currentcityid_260',['CurrentCityID',['../struct_transport___management___system___w_p_f_1_1_truck.html#a71ec212b9661e6c7e40d1f2595f0ce64',1,'Transport_Management_System_WPF::Truck']]],
  ['customer_5fname_261',['Customer_Name',['../struct_transport___management___system___w_p_f_1_1_customer.html#a4b076abe3c377803ce89183a4fd4833a',1,'Transport_Management_System_WPF::Customer']]]
];

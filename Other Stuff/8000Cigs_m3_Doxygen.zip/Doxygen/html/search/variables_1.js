var searchData=
[
  ['buyer_254',['buyer',['../class_transport___management___system___w_p_f_1_1_main_window.html#a37653ae01d60682a07e052147dff7d50',1,'Transport_Management_System_WPF::MainWindow']]]
];

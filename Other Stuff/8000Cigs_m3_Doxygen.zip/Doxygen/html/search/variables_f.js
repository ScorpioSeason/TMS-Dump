var searchData=
[
  ['waiting_5for_5ftransit_294',['Waiting_or_Transit',['../struct_transport___management___system___w_p_f_1_1_truck.html#a81ccff97235613b950395988d4e26d52',1,'Transport_Management_System_WPF::Truck']]]
];

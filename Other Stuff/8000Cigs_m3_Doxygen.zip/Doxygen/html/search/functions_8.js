var searchData=
[
  ['newlog_227',['NewLog',['../class_t_m_sw_pages_1_1_t_m_s_logger.html#a34e534b54ac36d38c33d7a8cb5abb7c7',1,'TMSwPages.TMSLogger.NewLog(string newLogString)'],['../class_t_m_sw_pages_1_1_t_m_s_logger.html#a949d7d962a3a8f19556a72c610a23340',1,'TMSwPages.TMSLogger.NewLog(string newLogString)']]]
];

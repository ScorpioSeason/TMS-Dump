var searchData=
[
  ['origin_317',['origin',['../class_transport___management___system___w_p_f_1_1_contract.html#a94cc2bb53b867ee05003849bb3d954d6',1,'Transport_Management_System_WPF.Contract.origin()'],['../struct_unit_test_t_m_s_1_1_planner_class_tests_1_1_testing_contract.html#acf3066dfc08cd9b25118e64c59916eab',1,'UnitTestTMS.PlannerClassTests.TestingContract.origin()']]]
];

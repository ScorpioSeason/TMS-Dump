var searchData=
[
  ['openconnection_228',['OpenConnection',['../class_transport___management___system___w_p_f_1_1_s_q_l___query.html#a84f129cd23e49a64a4d0a31b7cea2e21',1,'Transport_Management_System_WPF.SQL_Query.OpenConnection()'],['../class_transport___management___system___w_p_f_1_1_s_q_l___query___t_m_s.html#aee1eea15a09e4b889f7f595db573dc85',1,'Transport_Management_System_WPF.SQL_Query_TMS.OpenConnection()']]]
];

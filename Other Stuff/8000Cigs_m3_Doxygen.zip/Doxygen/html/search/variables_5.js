var searchData=
[
  ['is_5fcomplete_270',['Is_Complete',['../struct_transport___management___system___w_p_f_1_1_trip___ticket.html#a478f4ac1e28bf46a22e1765d96dada0b',1,'Transport_Management_System_WPF::Trip_Ticket']]],
  ['is_5freefer_271',['Is_Reefer',['../struct_transport___management___system___w_p_f_1_1_trip___ticket.html#a027a527cbc51146bd409a8b2f188156d',1,'Transport_Management_System_WPF.Trip_Ticket.Is_Reefer()'],['../struct_transport___management___system___w_p_f_1_1_truck.html#a19d9ffdc88f86af4a2dcd36d8a490daf',1,'Transport_Management_System_WPF.Truck.Is_Reefer()']]]
];

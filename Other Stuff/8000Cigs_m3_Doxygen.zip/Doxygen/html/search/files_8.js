var searchData=
[
  ['viewlogdetails_2examl_2ecs_205',['ViewLogDetails.xaml.cs',['../_view_log_details_8xaml_8cs.html',1,'']]]
];

var searchData=
[
  ['sql_5fquery_176',['SQL_Query',['../class_transport___management___system___w_p_f_1_1_s_q_l___query.html',1,'Transport_Management_System_WPF']]],
  ['sql_5fquery_5ftms_177',['SQL_Query_TMS',['../class_transport___management___system___w_p_f_1_1_s_q_l___query___t_m_s.html',1,'Transport_Management_System_WPF']]]
];

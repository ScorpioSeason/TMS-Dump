var searchData=
[
  ['uid_293',['uid',['../class_transport___management___system___w_p_f_1_1_s_q_l___query.html#a9f88738a93abcfe0a2840de3d99487c3',1,'Transport_Management_System_WPF.SQL_Query.uid()'],['../class_transport___management___system___w_p_f_1_1_s_q_l___query___t_m_s.html#a5144ebf4b2142b813a27987515a9f031',1,'Transport_Management_System_WPF.SQL_Query_TMS.uid()']]]
];

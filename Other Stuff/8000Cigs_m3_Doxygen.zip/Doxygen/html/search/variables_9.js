var searchData=
[
  ['origincity_278',['OriginCity',['../struct_transport___management___system___w_p_f_1_1_route_sum_data.html#a3d2ddcb564dfc2322a2b50156df0f72e',1,'Transport_Management_System_WPF::RouteSumData']]]
];
